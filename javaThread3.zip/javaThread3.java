class Hi implements Runnable{
	public void run(){
		for(int i=0;i<=5;i++){
			System.out.println("Hi");
			try{
				Thread.sleep(2000);
			}catch(Exception e){

			}
		}
	}
}
class Hello implements Runnable{
	public void run(){
		for(int i=0;i<=5;i++){
			System.out.println("Hello");
			try{
				Thread.sleep(500);
			}catch(Exception e){

			}
		}
	}
}
public class javaThread3{
	public static void main(String[] args) {
		Hi h = new Hi();
		Hello he = new Hello();
		Thread t1 = new Thread(h);
		Thread t2 = new Thread(he);
		t1.start();
		t2.start();
	}
}