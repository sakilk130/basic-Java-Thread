class Hi{
	public void show(){
		for(int i=0;i<=5;i++){
			System.out.println("Hi");
		}
	}
}
class Hello{
	public void show(){
		for(int i=0;i<=5;i++){
			System.out.println("Hello");
		}
	}
}
public class javaThread{
	public static void main(String[] args){
		Hi h=new Hi();
		Hello he=new Hello();
		h.show();
		he.show();
	}
}